from django.apps import AppConfig


class Cv2Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'admin.myCV2'
